import React from 'react';
import AppShell from './AppShell';

export default function App() {
  return (
    <AppShell />
  );
}
