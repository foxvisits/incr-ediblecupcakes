import React from 'react';
import { Link, useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { ChefHat, Clock, Users, Star, ArrowLeft } from 'lucide-react';
import RecipeCard from '../components/RecipeCard';
import { validatedRecipes as recipes } from '../data/recipes';
import { useIsClient } from '../hooks/useIsClient';

const CategoriesPage = () => {
  const isClient = useIsClient();
  const { categoryId } = useParams<{ categoryId: string }>();
  
  const categoryInfo = {
    classic: {
      name: 'Classic Cupcakes',
      description: 'Timeless recipes that have been perfected over generations. These are the cupcakes that bring back childhood memories and create new ones.',
      color: 'from-blue-500 to-indigo-600',
      icon: '🧁'
    },
    keto: {
      name: 'Keto Cupcakes',
      description: 'Low-carb, high-fat cupcakes that don\'t compromise on taste. Perfect for maintaining your ketogenic lifestyle while satisfying your sweet tooth.',
      color: 'from-green-500 to-emerald-600',
      icon: '🥑'
    },
    vegan: {
      name: 'Vegan Cupcakes',
      description: 'Plant-based cupcakes that are kind to animals and the environment. Proving that vegan baking can be just as delicious and indulgent.',
      color: 'from-emerald-500 to-teal-600',
      icon: '🌱'
    },
    'nut-free': {
      name: 'Nut-Free Cupcakes',
      description: 'Safe and delicious cupcakes for those with nut allergies. Every recipe is carefully crafted to avoid cross-contamination while maximizing flavor.',
      color: 'from-amber-500 to-orange-600',
      icon: '🚫'
    },
    'gluten-free': {
      name: 'Gluten-Free Cupcakes',
      description: 'Cupcakes made without gluten but full of flavor and texture. Perfect for those with celiac disease or gluten sensitivity.',
      color: 'from-purple-500 to-violet-600',
      icon: '🌾'
    }
  };

  const currentCategory = categoryId ? categoryInfo[categoryId as keyof typeof categoryInfo] : null;
  const categoryRecipes = categoryId ? recipes.filter(recipe => recipe.category === categoryId) : [];

  if (!currentCategory) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Category Not Found</h1>
          <Link to="/recipes" className="text-rose-500 hover:text-rose-600 font-medium">
            Back to All Recipes
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-16 lg:pt-20">
      <Helmet>
        <title>{currentCategory.name} Recipes - Professional Tested | Incr-EdibleCupCakes</title>
        <meta name="description" content={`${currentCategory.description} Browse our collection of ${categoryRecipes.length} professional ${currentCategory.name.toLowerCase()} recipes with step-by-step instructions and expert tips.`} />
        <meta name="keywords" content={`${categoryId} cupcakes, ${currentCategory.name.toLowerCase()}, specialty baking, dietary cupcakes, professional recipes, ${categoryId} baking, allergen-free cupcakes`} />
        <link rel="canonical" href={`https://incr-ediblecupcakes.com/categories/${categoryId}`} />
        
        {/* Open Graph */}
        <meta property="og:title" content={`${currentCategory.name} Recipes | Incr-EdibleCupCakes`} />
        <meta property="og:description" content={`Professional ${currentCategory.name.toLowerCase()} recipes tested and perfected by expert baker Sarah`} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`https://incr-ediblecupcakes.com/categories/${categoryId}`} />
        <meta property="og:image" content="https://incr-ediblecupcakes.com/A%20vibrant%2C%20mouth-watering%20cupcake%20scene.png" />
        
        {/* Twitter Cards */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={`${currentCategory.name} Recipes | Incr-EdibleCupCakes`} />
        <meta name="twitter:description" content={`Professional ${currentCategory.name.toLowerCase()} recipes tested and perfected by expert baker Sarah`} />
        <meta name="twitter:image" content="https://incr-ediblecupcakes.com/A%20vibrant%2C%20mouth-watering%20cupcake%20scene.png" />
        
        <script type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "CollectionPage",
            "name": `${currentCategory.name} Recipe Collection`,
            "description": `Professional ${currentCategory.name.toLowerCase()} recipes tested and perfected by expert baker Sarah`,
            "url": `https://incr-ediblecupcakes.com/categories/${categoryId}`,
            "breadcrumb": {
              "@type": "BreadcrumbList",
              "itemListElement": [
                {
                  "@type": "ListItem",
                  "position": 1,
                  "name": "Home",
                  "item": "https://incr-ediblecupcakes.com"
                },
                {
                  "@type": "ListItem",
                  "position": 2,
                  "name": "Recipes",
                  "item": "https://incr-ediblecupcakes.com/recipes"
                },
                {
                  "@type": "ListItem",
                  "position": 3,
                  "name": currentCategory.name,
                  "item": `https://incr-ediblecupcakes.com/categories/${categoryId}`
                }
              ]
            },
            "mainEntity": {
              "@type": "ItemList",
              "numberOfItems": categoryRecipes.length,
              "itemListElement": categoryRecipes.map((recipe, index) => ({
                "@type": "Recipe",
                "position": index + 1,
                "name": recipe.title,
                "url": `https://incr-ediblecupcakes.com/recipe/${recipe.slug}`,
                "image": recipe.image,
                "description": recipe.shortDescription,
                "recipeCategory": recipe.category,
                "aggregateRating": {
                  "@type": "AggregateRating",
                  "ratingValue": recipe.rating,
                  "reviewCount": Math.floor(recipe.rating * 50) + 50
                }
              }))
            }
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <section className={`relative py-20 bg-gradient-to-br ${currentCategory.color} overflow-hidden`}>
        <div className="absolute inset-0 pointer-events-none">
          <ClientOnly>
            <>
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute w-20 h-20 bg-white/10 rounded-full animate-float-random"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${i * 0.3}s`,
                  animationDuration: `${4 + i * 0.5}s`,
                }}
              />
            ))}
            </>
          </ClientOnly>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <Link
              to="/recipes"
              className="flex items-center space-x-2 text-white hover:text-yellow-300 transition-colors duration-300"
            >
              <ArrowLeft className="w-5 h-5" />
              <span className="font-medium">Back to All Recipes</span>
            </Link>
          </div>

          <div className="text-center text-white">
            <div className="text-6xl mb-6">{currentCategory.icon}</div>
            <h1 className="text-4xl sm:text-6xl font-bold mb-6 leading-tight drop-shadow-2xl">
              {currentCategory.name}
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
              {currentCategory.description}
            </p>
            <div className="flex items-center justify-center space-x-6 text-white/90">
              <div className="flex items-center space-x-2">
                <ChefHat className="w-6 h-6" />
                <span className="font-semibold">{categoryRecipes.length} Recipes</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-6 h-6 fill-current text-yellow-300" />
                <span className="font-semibold">
                  {(categoryRecipes.reduce((sum, recipe) => sum + recipe.rating, 0) / categoryRecipes.length).toFixed(1)} Avg Rating
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recipe Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {categoryRecipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {categoryRecipes.map((recipe, index) => (
                <div
                  key={recipe.id}
                  className="animate-fade-in-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <RecipeCard recipe={recipe} />
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="text-6xl mb-6">🔍</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">No recipes in this category yet</h3>
              <p className="text-gray-600 mb-6">
                We're working on adding more {currentCategory.name.toLowerCase()} to our collection.
              </p>
              <Link
                to="/recipes"
                className="px-6 py-3 bg-rose-500 text-white rounded-xl hover:bg-rose-600 transition-colors duration-300"
              >
                Browse All Recipes
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Related Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-12">
            Explore Other <span className="text-rose-500">Categories</span>
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {Object.entries(categoryInfo)
              .filter(([key]) => key !== categoryId)
              .map(([key, info], index) => (
                <Link
                  key={key}
                  to={`/categories/${key}`}
                  className="group bg-gradient-to-br from-rose-50 to-pink-50 rounded-2xl p-6 text-center hover:from-rose-100 hover:to-pink-100 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
                >
                  <div className="text-4xl mb-4">{info.icon}</div>
                  <h3 className="font-semibold text-gray-900 mb-2">{info.name}</h3>
                  <p className="text-sm text-gray-600">
                    {recipes.filter(r => r.category === key).length} recipes
                  </p>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CategoriesPage;